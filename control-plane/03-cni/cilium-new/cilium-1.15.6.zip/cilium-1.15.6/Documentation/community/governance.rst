.. only:: not (epub or latex or html)

    WARNING: You are looking at unreleased Cilium documentation.
    Please use the official rendered version released here:
    https://docs.cilium.io

.. _governance:

Governance
----------

Governance documentation can be found in the `Cilium Community repository <https://github.com/cilium/community/blob/main/GOVERNANCE.md>`__.