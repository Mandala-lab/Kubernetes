.. only:: not (epub or latex or html)

    WARNING: You are looking at unreleased Cilium documentation.
    Please use the official rendered version released here:
    https://docs.cilium.io

.. _helm_reference:

##############
Helm Reference
##############

The table below serves as a reference for the values that can be set on
Cilium's Helm chart.

.. include:: ./helm-values.rst
