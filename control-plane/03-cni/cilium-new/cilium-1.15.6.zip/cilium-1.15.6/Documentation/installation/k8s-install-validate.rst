Validate the Installation
=========================

.. tabs::

  .. tab:: Cilium CLI

    .. include:: /installation/cli-download.rst
    .. include:: /installation/cli-status.rst
    .. include:: /installation/cli-connectivity-test.rst

  .. tab:: Manually

    .. include:: /installation/kubectl-status.rst
    .. include:: /installation/kubectl-connectivity-test.rst
