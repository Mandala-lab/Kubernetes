**Requirements:**

* The AKS cluster must be created with ``--network-plugin none``. See the
  `Bring your own CNI <https://docs.microsoft.com/en-us/azure/aks/use-byo-cni?tabs=azure-cli>`_
  documentation for more details about BYOCNI prerequisites / implications.
